call("NanoToolStartup.install");
